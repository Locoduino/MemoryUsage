var searchData=
[
  ['sramdisplay',['SRamDisplay',['../MemoryUsage_8cpp.html#ae0f6b6157677326ae1e980a780a47001',1,'SRamDisplay(void):&#160;MemoryUsage.cpp'],['../MemoryUsage_8h.html#ae0f6b6157677326ae1e980a780a47001',1,'SRamDisplay(void):&#160;MemoryUsage.cpp']]],
  ['stack_5fcanary',['STACK_CANARY',['../MemoryUsage_8cpp.html#aaf4bc0f6929ec6fd223b829a0d3ecaa3',1,'MemoryUsage.cpp']]],
  ['stack_5fcompute',['STACK_COMPUTE',['../MemoryUsage_8h.html#afd641e7ea2d6b0f3313a54fabaa8dbca',1,'MemoryUsage.h']]],
  ['stack_5fdeclare',['STACK_DECLARE',['../MemoryUsage_8h.html#a0fa4214d0e8e544cb50ef1556f2724e6',1,'MemoryUsage.h']]],
  ['stack_5fprint',['STACK_PRINT',['../MemoryUsage_8h.html#adf7f4878f8a829d6f2f3431a18894dd7',1,'MemoryUsage.h']]],
  ['stack_5fprint_5ftext',['STACK_PRINT_TEXT',['../MemoryUsage_8h.html#a629e6a86364e8e879e5e0dc9e8dbc367',1,'MemoryUsage.h']]],
  ['stackpaint_5fprint',['STACKPAINT_PRINT',['../MemoryUsage_8h.html#af6bd1596cf67643983a2bc65a221582c',1,'MemoryUsage.h']]],
  ['stackpaint_5fprint_5ftext',['STACKPAINT_PRINT_TEXT',['../MemoryUsage_8h.html#afe182d3a03d963a1a4317fabfe040f95',1,'MemoryUsage.h']]]
];
